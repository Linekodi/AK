__NOTICE__

__This addon is no longer maintained by me, if you are interested in taking it over then please contact me via the Issues section. (You are welcome to submit it to the official Kodi Repo - just make sure you remove my name from it before you do it)__


![PinSentry](icon.png)

PinSentry is an addon that will allow you to set a pin code that you can then force to be input when you play a particular video file or navigate into a given TV Show or Plugin. There is also an option to force the user to enter a pin when the system starts, and then restrict the amount of time the user is allowed each day.

Please read the wiki for more details:

[Add-on:PinSentry](https://github.com/robwebset/script.pinsentry/wiki)
